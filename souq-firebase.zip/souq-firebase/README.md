# سوق المنطقة — النسخة الحقيقية (Firebase)

هذه النسخة تستبدل التخزين المحلي والرموز التجريبية بخدمات حقيقية:

- تسجيل الدخول: البريد (مع رابط تحقق)، رقم الهاتف (رسالة SMS)، Google، Facebook.
- الحسابات والإعلانات والبلاغات محفوظة على خادم Firebase ومشتركة بين كل المستخدمين.
- الإعلان الجديد يظهر عند الجميع فورًا بدون تحديث الصفحة.
- يبقى المستخدم مسجّلًا بعد أول دخول.

الملفات: `index.html` (الموقع) — `firebase-config.js` (إعدادك) — `firestore.rules` (قواعد الأمان) — `firebase.json` (إعداد النشر).

> هذه الملفات لم تُجرَّب على مشروع Firebase حقيقي من طرفي. إذا ظهر أي خطأ أثناء الإعداد، افتح أدوات المطوّر (F12 > Console) وأرسل لي نص الخطأ.

## الخطوات (حوالي 30 إلى 45 دقيقة)

### 1) إنشاء المشروع
1. ادخل إلى https://console.firebase.google.com بحساب Google.
2. Add project > اكتب اسمًا (مثلًا `souq-almantiqa`) > أكمل الخطوات (يمكنك إيقاف Google Analytics).

### 2) إضافة تطبيق ويب
1. من الصفحة الرئيسية للمشروع اضغط أيقونة الويب `</>`.
2. اكتب اسمًا واضغط Register app (لا تفعّل Hosting الآن).
3. انسخ قيم `firebaseConfig` وضعها في ملف `firebase-config.js` مكان القيم الحالية.

### 3) تفعيل طرق تسجيل الدخول
من القائمة: Build > Authentication > Get started > Sign-in method، ثم فعّل:
- **Email/Password**.
- **Phone** (الرسائل النصية).
- **Google**: فعّلها واختر بريد الدعم.
- **Facebook**:
  1. افتح https://developers.facebook.com وأنشئ تطبيقًا، وأضف منتج **Facebook Login**.
  2. انسخ App ID و App Secret من إعدادات التطبيق الأساسية إلى Firebase.
  3. انسخ رابط OAuth redirect URI الذي يعرضه Firebase وضعه في Facebook Login > Settings > Valid OAuth Redirect URIs.

ثم من Authentication > Settings > **Authorized domains** أضف نطاق موقعك بعد النشر (`xxx.web.app` يُضاف تلقائيًا).

### 4) قاعدة البيانات وقواعد الأمان
1. Build > Firestore Database > Create database (اختر أقرب منطقة، وابدأ بوضع Production).
2. افتح تبويب **Rules**، والصق محتوى ملف `firestore.rules`، ثم Publish.

### 5) النشر
**الطريقة أ: Firebase Hosting (موصى بها)**
```
npm install -g firebase-tools
firebase login
firebase init        # اختر Hosting و Firestore، وليس Overwrite لـ index.html
firebase deploy
```
(اختر المجلد الحالي كـ public directory، وأجب بـ No عند سؤال single-page app، وابقِ على `firestore.rules` الحالي.)
تحصل على رابط مثل `https://اسم-المشروع.web.app`.

**الطريقة ب: Netlify أو Cloudflare Pages**
اسحب المجلد على https://app.netlify.com/drop ثم أضف النطاق الناتج إلى Authorized domains في Firebase.

### 6) نطاق خاص
اشتر نطاقًا من أي مزوّد، ثم Hosting > Add custom domain واتبع الخطوات (شهادة HTTPS مجانية).

### 7) رسائل البريد بالعربية
Authentication > Templates > اختر اللغة العربية، وعدّل نص رسالة التحقق وإعادة تعيين كلمة المرور.

## الرسائل النصية (SMS)
- أثناء التجربة استخدم Authentication > Sign-in method > Phone > **Phone numbers for testing** لإضافة أرقام تجريبية برمز ثابت دون إرسال فعلي.
- لإرسال رسائل حقيقية قد يطلب Firebase ترقية المشروع إلى خطة **Blaze** (الدفع حسب الاستخدام مع حصة مجانية). راجع صفحة الأسعار الحالية قبل الإطلاق.
- تأكد أن إرسال الرسائل إلى الأردن (+962) مسموح من إعدادات SMS region policy.

## مراجعة البلاغات والإعلانات
- Firestore Database > مجموعة `reports`: كل بلاغ فيه رقم الإعلان `ad` والسبب `r` (fraud / abuse / misl) والملاحظة `n`.
- لحذف إعلان مخالف: افتح مجموعة `ads` واحذف المستند.

## تنبيهات مهمة
- تحديد الموقع يتم من جهاز المستخدم (GPS) ويمكن تزويره، فهو يقلل النصب ولا يمنعه تمامًا. للتحقق الأقوى نضيف لاحقًا Cloud Functions أو توثيق الهوية.
- بيانات التواصل بالإعلان يقرأها أي مستخدم مسجّل (الزر في الواجهة يخفيها فقط).
- الموقع يعرض آخر 300 إعلان. لعدد أكبر نضيف تقسيم الصفحات.
- الصور تُضغط وتُحفظ داخل مستند الإعلان (حد Firestore لحجم المستند 1 ميجابايت).
